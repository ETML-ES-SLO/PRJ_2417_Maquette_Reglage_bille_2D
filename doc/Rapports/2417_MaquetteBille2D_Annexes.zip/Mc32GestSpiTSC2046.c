/*--------------------------------------------------------*/
/*  Mc32gestSpiTSC2046.c                                  */
/*--------------------------------------------------------*/
/*  Gestion par SPI du contrôleur TSC2046E                */
/*--------------------------------------------------------*/

#include "app.h"
#include "Mc32gestSpiTSC2046.h"
#include "Mc32SpiUtil.h"
#include "peripheral/SPI/plib_spi.h"

/* --- Le TSC est câblé sur SPI1 du kit ------------------ */
#define TSC_SPI1   (SPI_ID_1)

/* Registres de contrôle (debug) ------------------------- */
//uint32_t  TSC_ConfigReg ;
//uint32_t  TSC_BaudReg   ;
extern const float Ts;
/*--------------------------------------------------------*/
/*  Configuration du bus SPI pour le TSC2046E             */
/*--------------------------------------------------------*/
static void SPI_ConfigureTSC(void)
{
    PLIB_SPI_Disable(TSC_SPI1);

    PLIB_SPI_BufferClear(TSC_SPI1);
    PLIB_SPI_StopInIdleDisable(TSC_SPI1);
    PLIB_SPI_PinEnable(TSC_SPI1, SPI_PIN_DATA_OUT);
    PLIB_SPI_CommunicationWidthSelect(TSC_SPI1, SPI_COMMUNICATION_WIDTH_8BITS);

    /* Vitesse : 2 MHz (≤ 2,08 MHz @2,7 V  – cf. datasheet) :contentReference[oaicite:2]{index=2} */
    PLIB_SPI_BaudRateSet(TSC_SPI1,SYS_CLK_PeripheralFrequencyGet(CLK_BUS_PERIPHERAL_1),100000UL);//2000000UL);

    /* Mode 0,0  – le TSC décale les données sur l’heure de descente */
    PLIB_SPI_InputSamplePhaseSelect (TSC_SPI1, SPI_INPUT_SAMPLING_PHASE_AT_END);
    PLIB_SPI_ClockPolaritySelect    (TSC_SPI1, SPI_CLOCK_POLARITY_IDLE_LOW);
    PLIB_SPI_OutputDataPhaseSelect  (TSC_SPI1, SPI_OUTPUT_DATA_PHASE_ON_ACTIVE_TO_IDLE_CLOCK);

    PLIB_SPI_MasterEnable(TSC_SPI1);
    PLIB_SPI_FramedCommunicationDisable(TSC_SPI1);
    PLIB_SPI_FIFOEnable(TSC_SPI1);

    PLIB_SPI_Enable(TSC_SPI1);

//    /* Pour contrôle/debug -------------------------------------- */
//    TSC_ConfigReg = SPI1CON;
//    TSC_BaudReg   = SPI1BRG;
}

/*--------------------------------------------------------*/
/*  Init public : à appeler une fois au démarrage          */
/*--------------------------------------------------------*/
void SPI_InitTSC2046(void)
{   
    SPI_ConfigureTSC();

    /* Aucun registre interne à écrire ; on lève simplement CS */
//    SPI1_CSOn();
    SPI1_CSOn();
}

/*--------------------------------------------------------*/
/*  Lecture «générique» : envoie cmd (1 octet) puis lit    */
/*  12 bits de résultat (deux octets)                      */
/*--------------------------------------------------------*/
uint16_t TSC2046_ReadRaw(uint8_t cmd)
{
    uint8_t msb;
    uint8_t lsb;
    uint16_t raw;

    SPI1_CSOff();

    /* Envoi du byte de commande (on ignore le retour) */
    spi_read1(cmd);

    /* Deux lectures «dummy» pour décaler les 16 bits
       → les 12 bits utiles sont alignés sur les MSB     */
    msb = spi_read1(0x00);
    lsb = spi_read1(0x00);

    SPI1_CSOn();

    raw = ( ((uint16_t)msb << 8) | lsb );  /* on se ramène sur 12 bits */
    return (raw >> 3);
}

uint16_t TSC2046_ReadPixel(uint16_t raw, uint16_t rawMin, uint16_t rawMax)
{
    if(raw <= rawMin)
    {
        return 0;
    }
    else if(raw >= rawMax)
    {
        return 1599;
    }
    else
    {
        return (uint32_t)(raw - rawMin) * 1599 / (rawMax - rawMin);
    }
    
}

uint16_t rawToPulse(uint16_t raw, uint16_t rawMin, uint16_t rawMax)
{
    if (raw <= rawMin)          
    {
        return 1800;             
    }

    if (raw >= rawMax)          
    {
        return 450;            
    }
    
    /* --------------------------------------------------------------
       Calcul

           pulse = 1800 tick - ((raw ? rawMin) / (rawMax ? rawMin)) � 1350 tick

       ? (raw ? rawMin)            : distance courante au minimum
       ? (rawMax ? rawMin)         : plage totale du capteur
       ? 1350 tick                   : delta total entre 450 et 1800 �s
       ? 1800 tick                    : point de d�part (-90�)
       -------------------------------------------------------------- */
    float pulse_f = 1800.0f - ((float)(raw - rawMin) / (float)(rawMax - rawMin)) * 1350.0f;
    
    return (uint16_t)pulse_f;    /* largeur d?impulsion finale */
}


uint16_t PRegulation(uint16_t raw, uint16_t zero, float direction, float kp)
{
    int16_t erreur;
    int16_t pulse;
    
    erreur = raw - zero;
    pulse = SERVO_PWM_NEUTRAL_TICK + direction * kp * erreur;
    
    if(pulse > SERVO_PWM_MAX_TICK)
    {
        pulse = SERVO_PWM_MAX_TICK;
    }
    
    if(pulse < SERVO_PWM_MIN_TICK)
    {
        pulse = SERVO_PWM_MIN_TICK;
    }

    return (uint16_t)pulse;
}


uint16_t IRegulation(uint16_t raw,  uint16_t zero, float direction, float ki, float Ts, int axe)              /* 0 = X, 1 = Y */
{
    static float integ[2] = {0.0f, 0.0f};
    float err;
    float capPos;
    float capNeg;

    err = direction * ((float)raw - (float)zero);
    integ[axe] += ki * Ts * err;                                /* int�gration */

    capPos =  SERVO_PWM_MAX_TICK - SERVO_PWM_NEUTRAL_TICK;
    capNeg = -(SERVO_PWM_NEUTRAL_TICK - SERVO_PWM_MIN_TICK);
    
    if (integ[axe] > capPos)
    {
        integ[axe] = capPos;
    }
    else if (integ[axe] < capNeg)
    {
        integ[axe] = capNeg;
    }

    return (int16_t)integ[axe];                            /* *** sign� *** */
}

uint16_t PIRegulation(uint16_t raw,  uint16_t zero, float direction, float kp, float ki, float Ts, int axe)           /* 0 = X, 1 = Y */
{
    int32_t pulseP  = PRegulation(raw, zero, direction, kp);     /* complet */
    int32_t correctionI   = IRegulation(raw, zero, direction, ki, Ts, axe);

    int32_t pulse   = pulseP + correctionI;

    if (pulse > SERVO_PWM_MAX_TICK)
    {
        pulse = SERVO_PWM_MAX_TICK;
    }
    else if (pulse < SERVO_PWM_MIN_TICK)
    {
        pulse = SERVO_PWM_MIN_TICK;
    }

    return (uint16_t)pulse;
}

int16_t DRegulation(uint16_t raw, uint16_t zero, float direction, float kd, float Ts, int axe)
{
    static float erreurPrecedente[2] = {0.0f, 0.0f};
    float erreur;
    float derive;
    float deriveMax;
    float deriveMin;
    
    
    erreur = direction * ((float)raw - (float)zero);
    derive = (kd * (erreur - erreurPrecedente[axe]) )/ Ts;        /* ?e */
    deriveMax =  SERVO_PWM_MAX_TICK - SERVO_PWM_NEUTRAL_TICK;
    deriveMin = -(SERVO_PWM_NEUTRAL_TICK - SERVO_PWM_MIN_TICK);
    

    erreurPrecedente[axe] = erreur;

    if (derive > deriveMax)
    {
        derive = deriveMax;
    }
    else if (derive < deriveMin)
    {
        derive = deriveMin;                                /* signe conserv� */
    }

    return (int16_t)derive;
    
}

uint16_t PDRegulation(uint16_t raw, uint16_t zero, float direction,float kp, float kd, float Ts, int axe)           /* 0 = X, 1 = Y */
{
    int32_t pulseP;
    int32_t correctionD;
    int32_t pulseRegule;

    pulseP       = PRegulation(raw, zero, direction, kp);
    correctionD  = DRegulation(raw, zero, direction, kd, Ts, axe);

    pulseRegule  = pulseP + correctionD ;

    if (pulseRegule > SERVO_PWM_MAX_TICK)
    {
        pulseRegule = SERVO_PWM_MAX_TICK;
    }
    else if (pulseRegule < SERVO_PWM_MIN_TICK)
    {
        pulseRegule = SERVO_PWM_MIN_TICK;
    }

    return (uint16_t)pulseRegule;
}

uint16_t PIDRegulation(uint16_t raw, uint16_t zero, float direction,float kp, float ki,float kd, float Ts, int axe)
{
    int32_t pulseP;
    int32_t correctionI;
    int32_t correctionD;
    uint16_t pulsePIDReg;
    
    
    pulseP  = PRegulation(raw, zero, direction, kp);     /* complet */
    correctionI = IRegulation(raw, zero, direction, ki, Ts, axe);
    correctionD = DRegulation(raw, zero, direction, kd, Ts, axe);
    
    pulsePIDReg = pulseP + correctionI + correctionD;
    if (pulsePIDReg > SERVO_PWM_MAX_TICK)
    {
        pulsePIDReg = SERVO_PWM_MAX_TICK;
    }
    else if (pulsePIDReg < SERVO_PWM_MIN_TICK)
    {
        pulsePIDReg = SERVO_PWM_MIN_TICK;
    }       
    return (uint16_t)pulsePIDReg;
}



uint16_t TSC2046_ReadRawX(void)
{
    return TSC2046_ReadRaw(TSC_CMD_X_POS);
}
uint16_t TSC2046_ReadRawY(void)
{
    return TSC2046_ReadRaw(TSC_CMD_Y_POS); 
}

