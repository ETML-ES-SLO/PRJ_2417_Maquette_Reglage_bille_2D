/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "app.h"
#include "system_config.h"
#include "system_definitions.h"
#include "Mc32gestSpiTSC2046.h"
#include "peripheral/oc/plib_oc.h"
#include "Mc32DriverLcd.h"
#include "GestMenu.h" 
#include "driver/usart/drv_usart_static.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

APP_DATA appData;
PID_DATA pidX;      /* axe X (gauche-droite)  */
PID_DATA pidY;      /* axe Y (haut-bas)       */
//static PID_RAW pidX;      /* axe X (gauche-droite)  */
//static PID_RAW pidY;      /* axe Y (haut-bas)       */


extern volatile float KpXY; /* d�clarations externes ? d�j� d�finies  */
extern volatile float KiXY; /*    dans menu.c                         */
extern volatile float KdXY;


// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;
    
    /* TODO: Initialize your application's state machine and other
     * parameters.
     */
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{ 
    /* Check the application's current state. */
    switch ( appData.state )
    {
        /* Application's initial state. */
        case APP_STATE_INIT:
        {
            lcd_init();
            lcd_bl_on();
            lcd_gotoxy(1,1);
            printf_lcd("2417_MaquetteBille2D");
            lcd_gotoxy(1,2);
            printf_lcd("MBR");
            menuInit(); 
            RTS_INIT();
            
            PLIB_INT_SourceEnable(INT_ID_0, INT_SOURCE_USART_1_RECEIVE);
            
           
            
            SPI_InitTSC2046();  // Initialisation du SPI pour le TSC2046
            DRV_TMR0_Start();   // Start du timer 1
            DRV_TMR1_Start();   // Start du timer 2
            DRV_TMR2_Start();   // Start du timer 3
            DRV_OC0_Start();    // Start de l'OC 2
            DRV_OC1_Start();    // Start de l'OC 3
            
            
            APP_UpdateState (APP_STATE_WAIT);
            break;
        }

        case APP_STATE_SERVICE_TASKS:
        {
//            uint16_t avgX;
//            uint16_t avgY;
            static uint16_t pwmX = 0;
            static uint16_t pwmY = 0;
//            static const float KpXY = 0.075f;
//            static const float KiXY = 0.006f;  
//            static const float KdXY = 0.02f;
            const float Ts = 0.002f;
            
            static float xfilt = 0.0f;   /* axe X */
            static float yfilt = 0.0f;   /* axe Y */
            
          
            static uint8_t  menuWasActive = 0;
            ReceiveGainFrame();
//            watchdogCTS();
            menuTache();
            if(menuActif())
            {  
                if(menuWasActive == 0)
                {
                    //sendPIDXY();
                    menuWasActive = 1;
                }
                else
                {
                    
                    
                }
                PLIB_OC_PulseWidth16BitSet(OC_ID_1, 1125);
                PLIB_OC_PulseWidth16BitSet(OC_ID_2, 1125);
            }
            else
            {
                
                appData.rawX = TSC2046_ReadRawX();  // Lecture via la reception en SPI du TSC2046 des valeurs en X sur le touchscreen
                appData.rawY = TSC2046_ReadRawY();  // Lecture via la reception en SPI du TSC2046 des valeurs en Y sur le touchscreen

                appData.posPixelX   = TSC2046_ReadPixel(appData.rawX, XMIN, XMAX);            
                appData.posPixelY   = 1599 - TSC2046_ReadPixel(appData.rawY, YMIN, YMAX);   
                
                xfilt += IIR_BETA * ((float)appData.rawX - xfilt);
                yfilt += IIR_BETA * ((float)appData.rawY - yfilt);
                                
//                moyenneGlissante(appData.rawX, appData.rawY, &avgX, &avgY);
                
                pwmX = PIDRegulation((uint16_t)xfilt, ZEROX, DIR_X, KpXY, KiXY, KdXY, Ts, 0); /* axe 0 */
                pwmY = PIDRegulation((uint16_t)yfilt, ZEROY, DIR_Y, KpXY, KiXY, KdXY, Ts, 1); /* axe 1 */

                PLIB_OC_PulseWidth16BitSet(OC_ID_1, pwmY);
                PLIB_OC_PulseWidth16BitSet(OC_ID_2, pwmX);
                lcdShowPos();   
                //sendPosition();
                
                menuWasActive = 0;
            }
            
            APP_UpdateState (APP_STATE_WAIT);
            break;
        }

        /* TODO: implement your application state machine.*/
        case APP_STATE_WAIT:
        {
            break;
        }

        /* The default state should never be executed. */
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }
}

void APP_UpdateState ( APP_STATES NewState )
{
    appData.state = NewState;
}

//void SendAsciiFrame(void)
//{
//    /* 1) �chelle gains ? entiers 0?9999 */
//    uint16_t kp_i = (uint16_t)(KpXY * 1000.0f + 0.5f);
//    uint16_t ki_i = (uint16_t)(KiXY * 1000.0f + 0.5f);
//    uint16_t kd_i = (uint16_t)(KdXY * 1000.0f + 0.5f);
//
//    /* 2) Format ASCII (37 caract�res) */
//    char buf[48];
//    int len = snprintf(buf, sizeof(buf),
//                       "!kp=%04uki=%04uki=%04uX=%04uY=%04u#\r\n",
//                       kp_i, ki_i, kd_i,
//                       appData.posPixelX,
//                       appData.posPixelY);
//
//    /* 3) Envoi octet par octet, bloquant tant que CTS=1 ou FIFO plein */
//    int i = 0;
//    while (i < len)
//    {
//        /* a) flow-control mat�riel : n?�mettre que si FT230X pr�t */
//        if (!CTS_IS_READY())
//        {
//            continue;
//        }
//
//        /* b) place libre dans la FIFO hardware (1 octet) ? */
//        if (DRV_USART0_TransmitBufferIsFull())
//        {
//            continue;
//        }
//        /* c) on peut envoyer */
//        DRV_USART0_WriteByte(buf[i++]);
//    }
//}

/*----------------------------------------------------------------------------*/
/*  R�ception non bloquante d?une trame � !kp=xxxxki=xxxxkd=xxxx# �           */
/*----------------------------------------------------------------------------*/
void ReceiveGainFrame(void)
{
    /* 1) D�finition de la petite machine d?�tats -------------------------- */
    typedef enum
    {
        ETAT_ATTENTE_EXCL,   /* on attend le caract�re ?!? */
        ETAT_RECEPTION       /* on collecte jusqu?au ?#?    */
    } ETAT_RX;

    static ETAT_RX etatCourant = ETAT_ATTENTE_EXCL;  /* �tat m�moris� */

    /* 2) Tampon de r�ception --------------------------------------------- */
    enum { TAILLE_TAMPON = 32 };
    static char    tamponTrame[TAILLE_TAMPON];
    static uint8_t indiceTampon = 0;

    /* 3) Boucle : on vide la FIFO tant qu?elle contient des octets -------- */
    while (DRV_USART0_ReceiverBufferIsEmpty() == false)
    {
        /* Lecture d?un octet depuis la FIFO mat�riel */
        char octet = DRV_USART0_ReadByte();

        /* ----------- TRAITEMENT SELON L?�TAT COURANT --------------------- */
        if (etatCourant == ETAT_ATTENTE_EXCL)
        {
            /* On attend le marqueur de d�but ?!? */
            if (octet == '!')
            {
                indiceTampon = 0;              /* remise � z�ro du tampon   */
                etatCourant  = ETAT_RECEPTION; /* on passe en mode collecte */
            }
            /* sinon : on ignore le caract�re                           */
        }
        else /* etatCourant == ETAT_RECEPTION */
        {
            /* On collecte jusqu?au ?#? */
            if (octet == '#')
            {
                /* ----- Fin de trame : on ferme la cha�ne C -------------- */
                tamponTrame[indiceTampon] = '\0';

                /* ----- D�codage des trois gains kp/ki/kd ---------------- */
                {
                    unsigned kp_i, ki_i, kd_i;
                    /* sscanf doit trouver EXACTEMENT 3 entiers            */
                    if (sscanf(tamponTrame,
                               "kp=%4uki=%4ukd=%4u",
                               &kp_i, &ki_i, &kd_i) == 3)
                    {
                        /* Conversion en flottant (3 d�cimales)           */
                        KpXY = kp_i / 1000.0f;
                        KiXY = ki_i / 1000.0f;
                        KdXY = kd_i / 1000.0f;
                    }
                }

                /* Retour � l?�tat d?attente d?une nouvelle trame           */
                etatCourant = ETAT_ATTENTE_EXCL;
            }
            else if (indiceTampon < (TAILLE_TAMPON - 1))
            {
                /* Si place disponible, on stocke l?octet                  */
                tamponTrame[indiceTampon] = octet;
                indiceTampon = indiceTampon + 1;
            }
            else
            {
                /* Tampon plein ? on abandonne la trame en cours            */
                etatCourant = ETAT_ATTENTE_EXCL;
            }
        }
    }
}

//void PollRequestSend(void)
//{
//    typedef enum {
//        REQ_WAIT_BANG,  // on attend '!'
//        REQ_WAIT_R      // on vient de voir '!' et on attend 'R'
//    } REQ_STATE;
//
//    static REQ_STATE reqState = REQ_WAIT_BANG;
//
//    // Tant qu?il y a des octets re�us dans la FIFO hardware?
//    while (!DRV_USART0_ReceiverBufferIsEmpty())
//    {
//        char c = DRV_USART0_ReadByte();
//
//        switch (reqState)
//        {
//            case REQ_WAIT_BANG:
//                if (c == '!')
//                    reqState = REQ_WAIT_R;
//                break;
//
//            case REQ_WAIT_R:
//                if (c == 'R')
//                {
//                    // S�quence compl�te re�ue ? on envoie la trame
//                    SendAsciiFrame();
//                }
//                // Dans tous les cas, on repart � la recherche de '!'
//                reqState = REQ_WAIT_BANG;
//                break;
//        }
//    }
//}

void moyenneGlissante(uint16_t rawX, uint16_t rawY, uint16_t *avgX, uint16_t *avgY)
{
    
    static uint16_t bufX[NOMBRE_ECHANTILLONS] = {0};
    static uint16_t bufY[NOMBRE_ECHANTILLONS] = {0};
    static uint32_t sumX = 0, sumY = 0;
    static uint16_t idxMA = 0; 
    // retire l?ancienne valeur
    sumX -= bufX[idxMA];
    sumY -= bufY[idxMA];

    /* Stocke la nouvelle */
    bufX[idxMA] = rawX;
    bufY[idxMA] = rawY;

    /* Ajoute au total */
    sumX += rawX;
    sumY += rawY;

    /* Calcule la moyenne */
    *avgX = (uint16_t)(sumX / NOMBRE_ECHANTILLONS);
    *avgY = (uint16_t)(sumY / NOMBRE_ECHANTILLONS);

    /* Avance l?index circulaire */
    idxMA++;
    if (idxMA >= NOMBRE_ECHANTILLONS)
    {
        idxMA = 0;
    }
}

/*---------------------------------------------------------------------------*/
/*  Envoi non bloquant de la position actuelle                              */
/*      Trame :  !X=xxxxY=xxxx# + CR/LF (18 caract�res)                     */
/*                                                                           */
/*  � chaque appel :                                                         */
/*      ? on g�n�re la trame une seule fois quand l?ancienne est termin�e    */
/*      ? on n?�met qu?UN seul octet (si le mat�riel est pr�t)               */
/*                                                                           */
/*  => La fonction est donc rapidement rendue et ne fige jamais le programme */
/*---------------------------------------------------------------------------*/
void sendPosition(void)
{
    /* --- 1) Variables statiques pour conserver l?avancement ------------- */
    static char    buf[24];     /* tampon contenant la trame compl�te        */
    static uint8_t len = 0;     /* longueur actuelle de la trame             */
    static uint8_t idx = 0;     /* prochain octet � envoyer                  */

    /* --- 2) (Re)construction de la trame quand tout a �t� envoy� -------- */
    if (idx >= len)             /* -> pr�c�dente trame totalement transmise  */
    {
        /* Conversion des coordonn�es X/Y en ASCII (?%04u? ? 4 chiffres)     */
        len = (uint8_t)sprintf(buf, "!X=%04uY=%04u#\r\n",
                               appData.posPixelX,
                               appData.posPixelY);
        idx = 0;                /* on repart du premier octet                */
    }

    /* --- 3) Conditions d?�mission --------------------------------------- */
    /* 3-a) Le circuit FT230X est-il pr�t ? (CTS = 0)                       */
    if (CTS_IS_READY() && !DRV_USART0_TransmitBufferIsFull())    /* CTS = 1 ? FT230X occupe?  (ligne haute)   */
    {
        DRV_USART0_WriteByte(buf[idx++]);
    }
}

//void sendPIDXY(void)
//{
//    static char     buf[48];
//    static uint8_t  len = 0;
//    static uint8_t  idx = 0;
//
//    while (idx >= len)
//    {
//        uint16_t kpi = (uint16_t)(KpXY * 1000.f + 0.5f);
//        uint16_t kii = (uint16_t)(KiXY * 1000.f + 0.5f);
//        uint16_t kdi = (uint16_t)(KdXY * 1000.f + 0.5f);
//
//        len = sprintf(buf, "!kp=%04uki=%04ukd=%04uX=%04uY=%04u#\r\n", kpi, kii, kdi,appData.posPixelX,appData.posPixelY);
//        idx = 0;
//    }
//
//    if (CTS_IS_READY() && !DRV_USART0_TransmitBufferIsFull())
//    {
//        DRV_USART0_WriteByte(buf[idx++]);
//    }
//}

//void sendPIDXY(void)
//{
//    /* 1) Pr�pare la trame -------------------------------------------------- */
//    uint16_t kpi = (uint16_t)(KpXY * 1000.f + 0.5f);
//    uint16_t kii = (uint16_t)(KiXY * 1000.f + 0.5f);
//    uint16_t kdi = (uint16_t)(KdXY * 1000.f + 0.5f);
//
//    char buf[48];
//    int len = sprintf(buf, "!kp=%04uki=%04ukd=%04uX=%04uY=%04u#\r\n", kpi, kii, kdi, appData.posPixelX, appData.posPixelY);
//    /* 2) �mission compl�te, octet par octet -------------------------------- */
//    int idx = 0;
//    while (idx < len)
//    {
//        /* a) flow-control mat�riel : on attend que CTS soit � 0               */
//        if (!CTS_IS_READY())
//            continue;                       /* CTS=1 ? FT230X pas pr�t        */
//
//        /* b) espace disponible dans la FIFO TX ?                              */
//        if (DRV_USART0_TransmitBufferIsFull())
//            continue;                       /* fifo pleine ? on patiente      */
//
//        /* c) on peut envoyer l?octet suivant                                  */
//        DRV_USART0_WriteByte(buf[idx++]);
//    }
//}
void sendPIDXY(void)
{
    static char     buf[48];
    static uint8_t  len = 0;
    static uint8_t  idx = 0;

    if (idx >= len)
    {
        uint16_t kpi = (uint16_t)(KpXY * 1000.f + 0.5f);
        uint16_t kii = (uint16_t)(KiXY * 1000.f + 0.5f);
        uint16_t kdi = (uint16_t)(KdXY * 1000.f + 0.5f);

        len = sprintf(buf, "!kp=%04uki=%04ukd=%04uX=%04uY=%04u#\r\n",
                      kpi, kii, kdi,
                      appData.posPixelX,
                      appData.posPixelY);
        idx = 0;
    }

    if (CTS_IS_READY() && !DRV_USART0_TransmitBufferIsFull())
    {
        DRV_USART0_WriteByte(buf[idx++]);
    }
}



//void watchdogCTS(void)
//{
//    static bool ignoreCTS = false;
//    static uint16_t ctsTimer = 0;
//    
//    if (PORTCbits.RC8 == 1)
//    {                               /* CTS haut ? on compte                 */
//        if (ctsTimer < CTS_TIMEOUT)
//        {
//            ctsTimer++;
//        }
//        else 
//        {/* ? 1 s ? on passe en mode ?no CTS?     */
//            ignoreCTS = true;
//        }
//    }
//    else
//    {                               /* CTS redevenu bas                     */
//        ctsTimer  = 0;
//        ignoreCTS = false;
//    }
////    return ignoreCTS;
//}
/*******************************************************************************
 End of File
 */
