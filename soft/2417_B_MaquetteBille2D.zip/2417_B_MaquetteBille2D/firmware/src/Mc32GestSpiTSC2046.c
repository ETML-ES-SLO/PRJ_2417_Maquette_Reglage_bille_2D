/*--------------------------------------------------------*/
/*  Mc32gestSpiTSC2046.c                                  */
/*--------------------------------------------------------*/
/*  Gestion par SPI du contr�leur TSC2046E                */
/*  Version enti�rement comment�e pour une compr�hension  */
/*  optimale. Les lignes de code d'origine ne sont pas    */
/*  modifi�es ; seuls des commentaires explicatifs ont    */
/*  �t� ajout�s.                                          */
/*--------------------------------------------------------*/

#include "app.h"                      /* D�finitions globales de l'application */
#include "Mc32gestSpiTSC2046.h"       /* Fichier d'en-t�te du module courant  */
#include "Mc32SpiUtil.h"              /* Fonctions utilitaires pour le bus SPI*/
#include "peripheral/SPI/plib_spi.h" /* Biblioth�que PLIB : acc�s registres SPI */

/* --- Le TSC est c�bl� sur SPI1 du kit ------------------ */
#define TSC_SPI1   (SPI_ID_1)          /* Identifiant mat�riel du contr�leur SPI employ� */

/* Registres de contr�le (debug) ------------------------- */
//uint32_t  TSC_ConfigReg ;           /* Gard� en commentaire : sert au debug */
//uint32_t  TSC_BaudReg   ;
extern const float Ts;                 /* P�riode d'�chantillonnage issue d'une horloge externe */

/*--------------------------------------------------------*/
/*  Configuration du bus SPI pour le TSC2046E             */
/*  Appel�e une seule fois � l'initialisation.            */
/*--------------------------------------------------------*/
static void SPI_ConfigureTSC(void)
{
    /* Arr�t du module SPI avant reconfiguration */
    PLIB_SPI_Disable(TSC_SPI1);

    /* Remise � z�ro du buffer et configuration */
    PLIB_SPI_BufferClear(TSC_SPI1);
    PLIB_SPI_StopInIdleDisable(TSC_SPI1);            /* Le module reste actif en Idle */
    PLIB_SPI_PinEnable(TSC_SPI1, SPI_PIN_DATA_OUT);  /* Activation de la broche SDO  */
    PLIB_SPI_CommunicationWidthSelect(TSC_SPI1, SPI_COMMUNICATION_WIDTH_8BITS); /* Trames de 8 bits */

    /* ----------------------------------------------------
       Vitesse du bus : 100 kHz (pour debug).               
       On peut monter � 2 MHz (valeur en commentaire).      
       La formule interne utilise la fr�quence du bus
       p�riph�rique 1 fournie par SYS_CLK_PeripheralFrequencyGet.
       ---------------------------------------------------- */
    PLIB_SPI_BaudRateSet(
        TSC_SPI1,
        SYS_CLK_PeripheralFrequencyGet(CLK_BUS_PERIPHERAL_1),
        100000UL); /* 100 kHz */

    /* Mode 0,0 : CPOL = 0, CPHA = 0.                       
       Le TSC d�cale les donn�es sur le flanc descendant    */
    PLIB_SPI_InputSamplePhaseSelect (TSC_SPI1, SPI_INPUT_SAMPLING_PHASE_AT_END);
    PLIB_SPI_ClockPolaritySelect    (TSC_SPI1, SPI_CLOCK_POLARITY_IDLE_LOW);
    PLIB_SPI_OutputDataPhaseSelect  (TSC_SPI1, SPI_OUTPUT_DATA_PHASE_ON_ACTIVE_TO_IDLE_CLOCK);

    /* Passage en mode ma�tre + FIFO activ�e */
    PLIB_SPI_MasterEnable(TSC_SPI1);
    PLIB_SPI_FramedCommunicationDisable(TSC_SPI1);  /* Pas de trame encadr�e */
    PLIB_SPI_FIFOEnable(TSC_SPI1);

    /* R�activation du module SPI avec la nouvelle config */
    PLIB_SPI_Enable(TSC_SPI1);

//    /* Pour contr�le/debug -------------------------------------- */
//    TSC_ConfigReg = SPI1CON;        /* Sauvegarde des registres de conf. */
//    TSC_BaudReg   = SPI1BRG;
}

/*--------------------------------------------------------*/
/*  Initialisation publique :                             */
/*  � appeler une fois au d�marrage de l'application.     */
/*--------------------------------------------------------*/
void SPI_InitTSC2046(void)
{
    SPI_ConfigureTSC();  /* Configure le bus SPI selon la fonction ci-dessus */

    /* Aucun registre interne � �crire sur le TSC :        */
    /* on se contente de lib�rer la ligne CS (active bas). */
    SPI1_CSOn();
}

/*--------------------------------------------------------*/
/*  Lecture brute :                                       */
/*  - Envoie une commande (1 octet)                       */
/*  - R�cup�re 12 bits de r�sultat align�s sur le MSB     */
/*--------------------------------------------------------*/
uint16_t TSC2046_ReadRaw(uint8_t cmd)
{
    uint8_t msb;   /* Poids fort retourn� par le TSC */
    uint8_t lsb;   /* Poids faible */
    uint16_t raw;  /* Valeur brute 12 bits reconstitu�e */

    SPI1_CSOff();  /* Abaisse CS pour d�buter la communication */

    /* Envoi du byte de commande ; le retour imm�diat est ignor� */
    spi_read1(cmd);

    /* Deux lectures "dummy" :                                   
       1) la premi�re d�cale les 8 premiers bits utiles           
       2) la seconde compl�te pour obtenir 16 bits align�s        */
    msb = spi_read1(0x00); /* Lecture du MSB */
    lsb = spi_read1(0x00); /* Lecture du LSB */

    SPI1_CSOn();   /* Rel�che CS : fin de transaction */

    /* Reconstruction sur 16 bits puis d�calage � droite de 3     
       pour repasser sur 12 bits utiles                           */
    raw = ( ((uint16_t)msb << 8) | lsb );
    return (raw >> 3);
}

/*--------------------------------------------------------*/
/*  Conversion brute -> pixel (0..1599)                   */
/*  - raw     : valeur lue (12 bits)                      */
/*  - rawMin  : valeur correspondant au bord � 0 �        */
/*  - rawMax  : valeur correspondant au bord � 1599 �     */
/*--------------------------------------------------------*/
uint16_t TSC2046_ReadPixel(uint16_t raw, uint16_t rawMin, uint16_t rawMax)
{
    if(raw <= rawMin)                  /* Saturation basse */
    {
        return 0;
    }
    else if(raw >= rawMax)             /* Saturation haute */
    {
        return 1599;
    }
    else
    {
        /* �chelle lin�aire sur la plage utile */
        return (uint32_t)(raw - rawMin) * 1599u / (rawMax - rawMin);
    }

}

/*--------------------------------------------------------*/
/*  rawToPulse : convertit la valeur capteur en largeur   */
/*               d'impulsion servo (en ticks �s)          */
/*--------------------------------------------------------*/
uint16_t rawToPulse(uint16_t raw, uint16_t rawMin, uint16_t rawMax)
{
    if (raw <= rawMin)          /* Extr�me gauche : -90�  */
    {
        return 1800;             /* 1800 �s */
    }

    if (raw >= rawMax)          /* Extr�me droite : +90� */
    {
        return 450;             /*  450 �s */
    }
    
    /* --------------------------------------------------------------
       Calcul lin�aire :                                             
           pulse = 1800 �s - ((raw - rawMin) / (rawMax - rawMin)) � 1350 �s
       - 1350 = 1800 - 450 (plage totale)                           
       - Le signe n�gatif inverse la direction.                      
       -------------------------------------------------------------- */
    float pulse_f = 1800.0f - ((float)(raw - rawMin) / (float)(rawMax - rawMin)) * 1350.0f;
    
    return (uint16_t)pulse_f;    /* Conversion float -> uint16 */
}


/*--------------------------------------------------------*/
/*  PRegulation : Correcteur proportionnel pur            */
/*  - raw       : valeur capteur courante                 */
/*  - zero      : consigne (position de repos)            */
/*  - direction : +1 ou -1 suivant l'inversion souhait�e  */
/*  - kp        : gain proportionnel                      */
/*--------------------------------------------------------*/
uint16_t PRegulation(uint16_t raw, uint16_t zero, float direction, float kp)
{
    int16_t erreur;        /* Erreur instantan�e (sign�e) */
    int16_t pulse;         /* Largeur d'impulsion finale */
    
    erreur = raw - zero;   /* �cart entre mesure et z�ro */
    pulse  = SERVO_PWM_NEUTRAL_TICK + direction * kp * erreur; /* Action P */
    
    /* Saturation pour rester dans la plage autoris�e du servo */
    if(pulse > SERVO_PWM_MAX_TICK)
    {
        pulse = SERVO_PWM_MAX_TICK;
    }
    
    if(pulse < SERVO_PWM_MIN_TICK)
    {
        pulse = SERVO_PWM_MIN_TICK;
    }

    return (uint16_t)pulse;
}

/*--------------------------------------------------------*/
/*  IRegulation : Correcteur int�gral                     */
/*  - axe 0 = X, 1 = Y pour disposer de deux accumulateurs*/
/*--------------------------------------------------------*/
uint16_t IRegulation(uint16_t raw,  uint16_t zero, float direction, float ki, float Ts, int axe)              /* 0 = X, 1 = Y */
{
    static float integ[2] = {0.0f, 0.0f}; /* Accumulateurs par axe */
    float err;        /* Erreur instantan�e */
    float capPos;     /* Limite sup�rieure */
    float capNeg;     /* Limite inf�rieure */

    err = direction * ((float)raw - (float)zero);      /* Erreur sign�e */
    integ[axe] += ki * Ts * err;                       /* Int�gration discr�te */

    /* Saturation de l'int�grale pour �viter le wind-up */
    capPos =  SERVO_PWM_MAX_TICK - SERVO_PWM_NEUTRAL_TICK;
    capNeg = -(SERVO_PWM_NEUTRAL_TICK - SERVO_PWM_MIN_TICK);
    
    if (integ[axe] > capPos)
    {
        integ[axe] = capPos;
    }
    else if (integ[axe] < capNeg)
    {
        integ[axe] = capNeg;
    }

    return (int16_t)integ[axe]; /* *** Retourne une correction sign�e *** */
}

/*--------------------------------------------------------*/
/*  PIRegulation : Correcteur proportionnel + int�gral    */
/*--------------------------------------------------------*/
uint16_t PIRegulation(uint16_t raw,  uint16_t zero, float direction, float kp, float ki, float Ts, int axe)           /* 0 = X, 1 = Y */
{
    int32_t pulseP  = PRegulation(raw, zero, direction, kp);     /* Terme P complet */
    int32_t correctionI   = IRegulation(raw, zero, direction, ki, Ts, axe);

    int32_t pulse   = pulseP + correctionI;                      /* Somme des actions */

    /* Saturation globale */
    if (pulse > SERVO_PWM_MAX_TICK)
    {
        pulse = SERVO_PWM_MAX_TICK;
    }
    else if (pulse < SERVO_PWM_MIN_TICK)
    {
        pulse = SERVO_PWM_MIN_TICK;
    }

    return (uint16_t)pulse;
}

/*--------------------------------------------------------*/
/*  DRegulation : Correcteur d�rivatif                    */
/*--------------------------------------------------------*/
int16_t DRegulation(uint16_t raw, uint16_t zero, float direction, float kd, float Ts, int axe)
{
    static float erreurPrecedente[2] = {0.0f, 0.0f}; /* M�moire par axe */
    float erreur;      /* Erreur instantan�e */
    float derive;      /* Terme d�riv� */
    float deriveMax;   /* Saturation + */
    float deriveMin;   /* Saturation - */
    
    
    erreur = direction * ((float)raw - (float)zero);
    derive = (kd * (erreur - erreurPrecedente[axe]) )/ Ts; /* (?e)/Ts */
    
    deriveMax =  SERVO_PWM_MAX_TICK - SERVO_PWM_NEUTRAL_TICK;
    deriveMin = -(SERVO_PWM_NEUTRAL_TICK - SERVO_PWM_MIN_TICK);
    

    erreurPrecedente[axe] = erreur; /* Mise � jour pour l'appel suivant */

    /* Saturation du terme D pour ne pas d�passer la m�canique */
    if (derive > deriveMax)
    {
        derive = deriveMax;
    }
    else if (derive < deriveMin)
    {
        derive = deriveMin;                                /* signe conserv� */
    }

    return (int16_t)derive;
    
}

/*--------------------------------------------------------*/
/*  PDRegulation : Proportionnel + d�riv�                 */
/*--------------------------------------------------------*/
uint16_t PDRegulation(uint16_t raw, uint16_t zero, float direction,float kp, float kd, float Ts, int axe)           /* 0 = X, 1 = Y */
{
    int32_t pulseP;          /* Terme P */
    int32_t correctionD;     /* Terme D */
    int32_t pulseRegule;     /* Somme r�gul�e */

    pulseP       = PRegulation(raw, zero, direction, kp);
    correctionD  = DRegulation(raw, zero, direction, kd, Ts, axe);

    pulseRegule  = pulseP + correctionD ;

    if (pulseRegule > SERVO_PWM_MAX_TICK)
    {
        pulseRegule = SERVO_PWM_MAX_TICK;
    }
    else if (pulseRegule < SERVO_PWM_MIN_TICK)
    {
        pulseRegule = SERVO_PWM_MIN_TICK;
    }

    return (uint16_t)pulseRegule;
}

/*--------------------------------------------------------*/
/*  PIDRegulation : Proportionnel + Int�gral + D�riv�      */
/*--------------------------------------------------------*/
uint16_t PIDRegulation(uint16_t raw, uint16_t zero, float direction,float kp, float ki,float kd, float Ts, int axe)
{
    int32_t pulseP;        /* Terme P */
    int32_t correctionI;   /* Terme I */
    int32_t correctionD;   /* Terme D */
    uint16_t pulsePIDReg;  /* R�sultat combin� satur� */
    
    
    pulseP  = PRegulation(raw, zero, direction, kp);     /* Terme P complet */
    correctionI = IRegulation(raw, zero, direction, ki, Ts, axe);
    correctionD = DRegulation(raw, zero, direction, kd, Ts, axe);
    
    pulsePIDReg = pulseP + correctionI + correctionD;
    if (pulsePIDReg > SERVO_PWM_MAX_TICK)
    {
        pulsePIDReg = SERVO_PWM_MAX_TICK;
    }
    else if (pulsePIDReg < SERVO_PWM_MIN_TICK)
    {
        pulsePIDReg = SERVO_PWM_MIN_TICK;
    }       
    return (uint16_t)pulsePIDReg;
}



/*--------------------------------------------------------*/
/*  Wrappers simplifi�s pour la lecture des axes X et Y   */
/*--------------------------------------------------------*/
uint16_t TSC2046_ReadRawX(void)
{
    return TSC2046_ReadRaw(TSC_CMD_X_POS); /* Commande pour l'axe X */
}
uint16_t TSC2046_ReadRawY(void)
{
    return TSC2046_ReadRaw(TSC_CMD_Y_POS); /* Commande pour l'axe Y */
}
