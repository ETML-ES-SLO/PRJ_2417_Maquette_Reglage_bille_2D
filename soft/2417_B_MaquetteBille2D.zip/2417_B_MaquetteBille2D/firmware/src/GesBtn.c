//---------------------------------------------------------------------------
// Fichier      : GesBtn.c
// Description  : Impl�mentation du pilote de gestion des boutons.
//---------------------------------------------------------------------------

#include "GesBtn.h"
#include "Mc32Debounce.h"

// Descripteurs des signaux pour le traitement anti-rebond
S_SwitchDescriptor DescrSW0;
S_SwitchDescriptor DescrSW1;
S_SwitchDescriptor DescrSW2;
S_SwitchDescriptor DescrSW3;

// Structures pour le traitement des �tats des boutons (m�moire allou�e)
S_Btn_Descriptor SW0 = {0};   // Btn_UP
S_Btn_Descriptor SW1 = {0};   // Btn_DOWN
S_Btn_Descriptor SW2 = {0};   // Btn_LEFT
S_Btn_Descriptor SW3 = {0};   // Btn_RIGHT

//----------------------------------------------------------------------------------//
//-- nom fct : ScanBtn  
//-- param�tre entr�e : bool - ValSW0, bool - ValSW1, bool - ValSW2, bool - ValSW3 
//-- param�tre sortie : void - aucun 
//-- param�tre r�f�rence (IN-OUT) :   aucun 
//-- description : Fonction principale � appeler cycliquement. Elle g�re l'anti-rebond 
//                 des 4 boutons puis met � jour leurs �tats internes via GestBtn. 
//-- d�monstration : N/A 
//-- aide - r�f�rence - lien : N�cessite l'appel de DoDebounce (Mc32Debounce.h) 
//----------------------------------------------------------------------------------//
void ScanBtn (bool ValSW0, bool ValSW1, bool ValSW2, bool ValSW3) {
   // Traitement antirebond sur SW0, SW1, SW2, SW3
   DoDebounce (&DescrSW0, ValSW0);
   DoDebounce (&DescrSW1, ValSW1);
   DoDebounce (&DescrSW2, ValSW2);
   DoDebounce (&DescrSW3, ValSW3);
   
   // Gestion de l'appui sur bouton SW0, SW1, SW2, SW3
   GestBtn(&SW0, &DescrSW0);
   GestBtn(&SW1, &DescrSW1);
   GestBtn(&SW2, &DescrSW2);
   GestBtn(&SW3, &DescrSW3);
}

//----------------------------------------------------------------------------------//
//-- nom fct : GestBtn  
//-- param�tre entr�e : aucun 
//-- param�tre sortie : void - aucun 
//-- param�tre r�f�rence (IN-OUT) :   S_Btn_Descriptor* - ptrSW, S_SwitchDescriptor* - ptrDescrSW 
//-- description : �value l'�tat d'un bouton sp�cifique. Incr�mente les compteurs de 
//                 pression, d�termine si l'appui est simple (SEL) ou long (HOLD) au 
//                 rel�chement, et g�re le d�lai de d�clenchement de l'inactivit�.
//-- d�monstration : N/A
//-- aide - r�f�rence - lien : Utilise les macros PRESS_DURATION et MAX_INACTIVITY_DELAY 
//----------------------------------------------------------------------------------//
void GestBtn (S_Btn_Descriptor *ptrSW, S_SwitchDescriptor *ptrDescrSW) {        
    // --- Phase 1 : Le bouton est actuellement maintenu press� ---
    if(DebounceIsPressed(ptrDescrSW)) {
        ptrSW->PressDuration += 1;
        
        // R�initialisation de l'inactivit� d�s qu'une pression est d�tect�e
        if(BtnNoActivity(ptrSW)) {
            BtnClearInactivity(ptrSW);
        } else {
            ptrSW->InactivityDuration = 0;
        }
    } 
    
    // --- Phase 2 : Le bouton vient d'�tre rel�ch� ---
    if(DebounceIsReleased(ptrDescrSW)) {
        DebounceClearPressed(ptrDescrSW);
        DebounceClearReleased(ptrDescrSW);
        
        // D�termination du type d'appui en fonction de la dur�e
        if(ptrSW->PressDuration < PRESS_DURATION) {
            ptrSW->SEL = 1;                              // Appui simple
        } else {
            ptrSW->HOLD = 1;                             // Appui prolong�
        }
        
        ptrSW->PressDuration = 0; // Remise � z�ro pour le prochain cycle
        
        // R�initialisation de l'inactivit� au rel�chement
        if(BtnNoActivity(ptrSW)) {
            BtnClearInactivity(ptrSW);
        } else {
            ptrSW->InactivityDuration = 0;
        }
    }  
    
    // --- Phase 3 : Gestion de l'inactivit� globale du bouton ---
    if(ptrSW->InactivityDuration < MAX_INACTIVITY_DELAY) {
        ptrSW->InactivityDuration += 1;
    } else {
        ptrSW->NoActivity = 1; // Le d�lai maximum est atteint, flag lev�
    } 
}

//----------------------------------------------------------------------------------//
//-- nom fct : BtnInit  
//-- param�tre entr�e : aucun 
//-- param�tre sortie : void - aucun 
//-- param�tre r�f�rence (IN-OUT) :   aucun 
//-- description : Initialise � z�ro les structures mat�rielles (anti-rebond) et 
//                 logicielles (SEL, HOLD, compteurs) des 4 boutons.
//-- d�monstration : N/A 
//-- aide - r�f�rence - lien : Doit �tre appel�e � l'initialisation du syst�me. 
//----------------------------------------------------------------------------------//
void BtnInit (void) {
   // Initialisation des descripteurs de touches mat�riels
    DebounceInit(&DescrSW0);
    DebounceInit(&DescrSW1);
    DebounceInit(&DescrSW2);
    DebounceInit(&DescrSW3);
   
   // Init de la structure SW0 (Bouton UP)
    SW0.SEL = 0;              // �v�nement action SEL
    SW0.HOLD = 0;             // �v�nement action HOLD
    SW0.NoActivity = 0;       // Indication d'activit�
    SW0.PressDuration = 0;    // Pour dur�e pression du P.B.
    SW0.InactivityDuration = 0; // Dur�e inactivit�
    

   // Init de la structure SW1 (Bouton DOWN)
    SW1.SEL = 0;              
    SW1.HOLD = 0;             
    SW1.NoActivity = 0;      
    SW1.PressDuration = 0;   
    SW1.InactivityDuration = 0; 
    
   // Init de la structure SW2 (Bouton LEFT)
    SW2.SEL = 0;              
    SW2.HOLD = 0;             
    SW2.NoActivity = 0;      
    SW2.PressDuration = 0;   
    SW2.InactivityDuration = 0; 
    
   // Init de la structure SW3 (Bouton RIGHT)
    SW3.SEL = 0;              
    SW3.HOLD = 0;             
    SW3.NoActivity = 0;      
    SW3.PressDuration = 0;   
    SW3.InactivityDuration = 0; 
 }

//----------------------------------------------------------------------------------//
//-- nom fct : BtnIsSEL  
//-- param�tre entr�e : aucun 
//-- param�tre sortie : bool - �tat du flag SEL 
//-- param�tre r�f�rence (IN-OUT) :   S_Btn_Descriptor* - pBtn 
//-- description : Retourne true si une action d'appui simple (SEL) a �t� d�tect�e 
//                 sur le bouton pass� en param�tre.
//-- d�monstration : N/A 
//-- aide - r�f�rence - lien : N/A 
//----------------------------------------------------------------------------------//
bool BtnIsSEL (S_Btn_Descriptor *pBtn) {
   return (pBtn->SEL);
}

//----------------------------------------------------------------------------------//
//-- nom fct : BtnIsHOLD  
//-- param�tre entr�e : aucun 
//-- param�tre sortie : bool - �tat du flag HOLD 
//-- param�tre r�f�rence (IN-OUT) :   S_Btn_Descriptor* - pBtn 
//-- description : Retourne true si une action d'appui long (HOLD) a �t� d�tect�e 
//                 sur le bouton pass� en param�tre.
//-- d�monstration : N/A 
//-- aide - r�f�rence - lien : N/A 
//----------------------------------------------------------------------------------//
bool BtnIsHOLD (S_Btn_Descriptor *pBtn) {
   return (pBtn->HOLD);
}

//----------------------------------------------------------------------------------//
//-- nom fct : BtnNoActivity  
//-- param�tre entr�e : aucun 
//-- param�tre sortie : bool - �tat du flag NoActivity 
//-- param�tre r�f�rence (IN-OUT) :   S_Btn_Descriptor* - pBtn 
//-- description : Retourne true si aucune activit� n'a �t� d�tect�e sur le bouton 
//                 depuis MAX_INACTIVITY_DELAY.
//-- d�monstration : N/A 
//-- aide - r�f�rence - lien : N/A 
//----------------------------------------------------------------------------------//
bool BtnNoActivity (S_Btn_Descriptor *pBtn) {
   return (pBtn->NoActivity);
}

//----------------------------------------------------------------------------------//
//-- nom fct : BtnClearSEL  
//-- param�tre entr�e : aucun 
//-- param�tre sortie : void - aucun 
//-- param�tre r�f�rence (IN-OUT) :   S_Btn_Descriptor* - pBtn 
//-- description : Acquitte (remet � 0) le flag indiquant un appui simple (SEL) une 
//                 fois que l'application a trait� l'�v�nement.
//-- d�monstration : N/A 
//-- aide - r�f�rence - lien : N/A 
//----------------------------------------------------------------------------------//
void BtnClearSEL (S_Btn_Descriptor *pBtn) {
   pBtn->SEL = 0;
}

//----------------------------------------------------------------------------------//
//-- nom fct : BtnClearHOLD  
//-- param�tre entr�e : aucun 
//-- param�tre sortie : void - aucun 
//-- param�tre r�f�rence (IN-OUT) :   S_Btn_Descriptor* - pBtn 
//-- description : Acquitte (remet � 0) le flag indiquant un appui long (HOLD) une 
//                 fois que l'application a trait� l'�v�nement.
//-- d�monstration : N/A 
//-- aide - r�f�rence - lien : N/A 
//----------------------------------------------------------------------------------//
void BtnClearHOLD (S_Btn_Descriptor *pBtn) {
   pBtn->HOLD = 0;
}

//----------------------------------------------------------------------------------//
//-- nom fct : BtnClearInactivity  
//-- param�tre entr�e : aucun 
//-- param�tre sortie : void - aucun 
//-- param�tre r�f�rence (IN-OUT) :   S_Btn_Descriptor* - pBtn 
//-- description : Acquitte le flag d'inactivit� et r�initialise le compteur associ� 
//                 pour relancer le chronom�trage.
//-- d�monstration : N/A 
//-- aide - r�f�rence - lien : N/A 
//----------------------------------------------------------------------------------//
void BtnClearInactivity (S_Btn_Descriptor *pBtn) {
  pBtn->NoActivity = 0;
  pBtn->InactivityDuration = 0;
}

/* *****************************************************************************
 End of File
 */